<?php

//namespace ExtendBuilder;
//
//add_action( 'dp_duplicate_page', function($new_post_id, $post, $status) {
//    $original_post_data = new PostData($post->ID);
//    $json = $original_post_data->get_data("json");
//    if ($json) {
//        $new_post_data = new PostData($new_post_id);
//        $new_post_data->set_data("json", $json, true);
//    }
//}, 999, 3);
