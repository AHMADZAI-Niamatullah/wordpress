<?php

/**
 * Class Forminator_Addon_Campaignmonitor_Wp_Api_Exception
 * Exception holder for Campaignmonitor wp api
 *
 * @since 1.0 Campaignmonitor Addon
 */
class Forminator_Addon_Campaignmonitor_Wp_Api_Exception extends Forminator_Addon_Campaignmonitor_Exception {
}
