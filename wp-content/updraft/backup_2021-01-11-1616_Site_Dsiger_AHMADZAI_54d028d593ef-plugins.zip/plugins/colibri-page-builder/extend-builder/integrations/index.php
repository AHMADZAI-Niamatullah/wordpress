<?php
namespace ExtendBuilder;

require_once __DIR__ . '/duplicate-post.php';
require_once __DIR__ . '/sg-optimizer.php';
require_once __DIR__ . '/jetpack.php';
require_once __DIR__ . '/multilanguage.php';
require_once __DIR__ . '/woocommerce/index.php';
