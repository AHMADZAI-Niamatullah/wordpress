<?php

namespace ExtendBuilder;

require_once __DIR__ . '/base.php';
require_once __DIR__ . '/wrapper.php';
require_once __DIR__ . '/render-js.php';
require_once __DIR__ . '/menu-1.php';
require_once __DIR__ . '/video.php';
require_once __DIR__ . '/search.php';
require_once __DIR__ . '/gallery.php';
require_once __DIR__ . '/general.php';
require_once __DIR__ . '/blog-posts.php';
require_once __DIR__ . '/widget-area.php';
require_once __DIR__ . '/colibri_page_title.php';
require_once __DIR__ . '/lana-breadcrumb.php';
require_once __DIR__ . '/gallery-slideshow.php';
require_once __DIR__ . '/breadcrumb.php';
require_once __DIR__ . '/blog/index.php';
require_once __DIR__ . '/newsletter.php';
require_once __DIR__ . '/filters.php';
require_once __DIR__ . '/contact-form.php';
