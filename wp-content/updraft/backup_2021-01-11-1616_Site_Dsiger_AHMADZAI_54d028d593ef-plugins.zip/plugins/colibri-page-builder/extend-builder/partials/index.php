<?php

namespace ExtendBuilder;

require_once __DIR__ . '/inheritance.php';
require_once __DIR__ . '/filters.php';
require_once __DIR__ . '/partials.php';
require_once __DIR__ . '/output.php';
require_once __DIR__ . '/regenerate.php';
