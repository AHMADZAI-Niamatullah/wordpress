<?php

namespace ExtendBuilder;

require_once __DIR__ . '/api.php';
require_once __DIR__ . '/partials.php';
require_once __DIR__ . '/menu-1.php';
require_once __DIR__ . '/newsletter.php';
require_once __DIR__ . '/pages.php';
require_once __DIR__ . '/presets.php';
require_once __DIR__ . '/post.php';
