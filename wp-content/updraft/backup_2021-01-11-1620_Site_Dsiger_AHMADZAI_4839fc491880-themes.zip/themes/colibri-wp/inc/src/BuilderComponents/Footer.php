<?php


namespace ColibriWP\Theme\BuilderComponents;


class Footer extends BuilderComponentBase {

    /**
     * @return string
     */
    protected function getName() {
        return 'footer';
    }


}
