<?php
do_action('honeywaves_footer_section_hook');?>	
</div>
<?php wp_footer();?>	
</body>
</html>