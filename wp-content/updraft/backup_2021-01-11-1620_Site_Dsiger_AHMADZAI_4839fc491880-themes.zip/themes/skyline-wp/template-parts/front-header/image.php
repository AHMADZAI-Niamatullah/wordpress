<div data-colibri-id="7-h33" class="d-block style-786 style-local-7-h33 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div class="h-image__frame-container-outer">
    <div class="h-image__frame-container">
      <?php $component->printImage('wp-image- style-786-image style-local-7-h33-image',''); ?>
      <div class="h-image__frame h-hide-lg h-hide-md h-hide-sm style-786-frameImage style-local-7-h33-frameImage <?php $component->printFrameClasses(); ?>"></div>
    </div>
  </div>
</div>
