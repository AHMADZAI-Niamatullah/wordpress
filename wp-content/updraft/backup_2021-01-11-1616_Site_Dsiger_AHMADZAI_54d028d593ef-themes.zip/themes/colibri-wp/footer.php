<?php colibriwp_theme()->get( 'footer' )->render(); ?>
</div><!-- #page -->
<?php wp_footer(); ?>
</body>
</html>
