<?php

get_header();
colibriwp_theme()->get( 'main-woo' )->render();
get_footer();
