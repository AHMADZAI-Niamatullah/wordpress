<div data-colibri-id="10-h27" class="page-title style-60 style-local-10-h27 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div class="h-page-title__outer style-60-outer style-local-10-h27-outer">
    <div class="h-global-transition-all">
      <?php colibriwp_page_title(array (
        'tag' => 'h1',
      )); ?>
    </div>
  </div>
</div>
