<div data-colibri-id="19-m1" class="style-103 style-local-19-m1 position-relative">
  <div data-colibri-component="section" data-colibri-id="19-m2" id="blog-posts" class="h-section h-section-global-spacing d-flex align-items-lg-center align-items-md-center align-items-center style-104 style-local-19-m2 position-relative">
    <div class="h-section-grid-container h-section-boxed-container">
      <div data-colibri-id="19-m3" class="h-row-container gutters-row-lg-3 gutters-row-md-2 gutters-row-2 gutters-row-v-lg-3 gutters-row-v-md-3 gutters-row-v-3 colibri-dynamic-list style-109 style-local-19-m3 position-relative">
        <div class="h-row justify-content-lg-start justify-content-md-start justify-content-start align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-3 gutters-col-md-2 gutters-col-2 gutters-col-v-lg-3 gutters-col-v-md-3 gutters-col-v-3 style-109-row style-local-19-m3-row">
          <?php colibriwp_theme()->get('archive-loop')->render(); ?>
        </div>
      </div>
      <?php colibriwp_layout_wrapper(array (
        'name' => 'navigation_container',
        'slug' => 'navigation-container-2',
      )); ?>
    </div>
  </div>
</div>
